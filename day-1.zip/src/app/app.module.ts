import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { MainApp } from './components/mainapp/MainApp.component';
import { Header } from './components/header/Header.component';
import { Footer } from './components/footer/Footer.component';
import { UserService } from './shared/services/user.service';
import { DepartmentService } from './shared/services/department.service';
import { FormsModule } from '@angular/forms';
import { RenderComponent } from './components/render/render.component';
import { ViewchildComponent } from './components/viewchild/viewchild.component';
import { ViewchildmainComponent } from './components/viewchildmain/viewchildmain.component'

@NgModule({
  // contains Components/Pipes/Directives
  declarations: [
    AppComponent,MainApp,Header,Footer, RenderComponent, ViewchildComponent, ViewchildmainComponent
  ],
  // contains Modules
  imports: [
    BrowserModule,FormsModule
  ],
  //contains Services
  providers: [UserService,DepartmentService],
  //contains first comp to load
  bootstrap: [AppComponent]
})
export class AppModule { }
