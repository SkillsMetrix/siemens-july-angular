import { Component, ViewChild } from '@angular/core';
import { ViewchildComponent } from '../viewchild/viewchild.component';

@Component({
  selector: 'app-viewchildmain',
  templateUrl: './viewchildmain.component.html',
  styleUrls: ['./viewchildmain.component.css']
})
export class ViewchildmainComponent {
@ViewChild(ViewchildComponent)
  private vc :ViewchildComponent;

  inc(){
    this.vc.increment()
  }
  dec(){
    this.vc.decrement()
  }
}
