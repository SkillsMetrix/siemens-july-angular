import { Component } from "@angular/core";
import { DepartmentService } from "src/app/shared/services/department.service";
import { UserService } from "src/app/shared/services/user.service";


@Component({
    selector:'header-app',
    templateUrl:'Header.component.html',
    styleUrls:['./header.component.css']
})
export class Header{

compname='Header Component'
users:string[]=[]
depts:string[]=[]
constructor(us:UserService,dept:DepartmentService){
    this.users=us.loadUsers()
    this.depts=dept.loadDepts()

}
}