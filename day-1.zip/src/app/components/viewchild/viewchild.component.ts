import { Component } from '@angular/core';

@Component({
  selector: 'app-viewchild',
  templateUrl: './viewchild.component.html',
  styleUrls: ['./viewchild.component.css']
})
export class ViewchildComponent {
  count=0
  message=''

  increment(){

    this.count++
    this.message=`Count is ${this.count}`
  }
  decrement(){
    this.count--
    this.message=`Count is ${this.count}`
  }

}
