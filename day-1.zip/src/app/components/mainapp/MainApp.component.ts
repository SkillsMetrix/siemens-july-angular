import { Component } from "@angular/core";


@Component({
    selector:'main-app',
    templateUrl:'MainApp.component.html'
})
export class MainApp{

compname='MainApp Component'
newcity='mumbai'
}