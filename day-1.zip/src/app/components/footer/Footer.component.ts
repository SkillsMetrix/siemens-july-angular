import { Component, Input } from "@angular/core";


@Component({
    selector: 'app-footer',
    templateUrl: 'Footer.component.html'
})
export class Footer {

    compname = 'Footer Component'
    @Input()
    mycity = 'pune'
    @Input()
    myprofile = 'https://media.sproutsocial.com/uploads/2022/06/profile-picture.jpeg'

    addUSer() {
        alert('user added')
    }


    people: any[] = [
        {
            "name": 'admin',
            "country": "USA"
        },
        {
            "name": 'Manager',
            "country": "India"
        },
        {
            "name": 'QA',
            "country": "Uk"
        }
    ]
    applyStyle(country: string) {
        switch (country) {
            case 'USA':
                return 'green'
            case 'Uk':
                return 'purple'
            case 'India':
                return 'blue'
            default:
                return null
        }
    }

}