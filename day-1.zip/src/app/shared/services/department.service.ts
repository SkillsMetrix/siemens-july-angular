import { Injectable } from "@angular/core";


@Injectable()
export class DepartmentService{

    loadDepts():string[]{
        return ['HR','Finance','Quality']
    }
}