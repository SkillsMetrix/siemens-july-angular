import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FormServiceService {

  addUserToDB(data: any) {

    this.http.post('https://aic-angular-default-rtdb.firebaseio.com/userdata.json', data)
      .subscribe((data) => {
        console.log(data);

      })


  }
  getDataFromDB() {
    return this.http.get('https://aic-angular-default-rtdb.firebaseio.com/userdata.json')
  }

  constructor(private http: HttpClient) { }
}
