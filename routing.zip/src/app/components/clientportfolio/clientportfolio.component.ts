import { Component } from '@angular/core';

@Component({
  selector: 'app-clientportfolio',
  templateUrl: './clientportfolio.component.html',
  styleUrls: ['./clientportfolio.component.css']
})
export class ClientportfolioComponent {

}
