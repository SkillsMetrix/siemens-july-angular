import { Component } from '@angular/core';

@Component({
  selector: 'app-userportfolio',
  templateUrl: './userportfolio.component.html',
  styleUrls: ['./userportfolio.component.css']
})
export class UserportfolioComponent {

}
