import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { UserdetailsComponent } from './components/userdetails/userdetails.component';
import { PortfolioComponent } from './components/portfolio/portfolio.component';
import { ClientportfolioComponent } from './components/clientportfolio/clientportfolio.component';
import { UserportfolioComponent } from './components/userportfolio/userportfolio.component';

const routes: Routes = [
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'userdetails/:id',component:UserdetailsComponent},
  {path:'portfolio',component:PortfolioComponent ,
    children:[
      {path:'client',component:ClientportfolioComponent},
      {path:'user',component:UserportfolioComponent}
    ]
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
