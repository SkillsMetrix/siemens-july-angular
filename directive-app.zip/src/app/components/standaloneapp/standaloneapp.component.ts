import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppStyleDirective } from 'src/app/shared/appstyle.directive';
import { Summary } from 'src/app/shared/summary.pipe';


@Component({
  selector: 'app-standaloneapp',
  templateUrl: './standaloneapp.component.html',
  styleUrls: ['./standaloneapp.component.css'],
  imports:[AppStyleDirective,FormsModule,CommonModule,Summary],
  standalone:true
})
export class StandaloneappComponent {
  color:''
  weight:''
  userInfo='this is all about standalone pipe'

}
