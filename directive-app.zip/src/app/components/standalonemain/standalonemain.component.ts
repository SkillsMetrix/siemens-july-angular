import { Component } from '@angular/core';
import { StandaloneappComponent } from '../standaloneapp/standaloneapp.component';

@Component({
  selector: 'app-standalonemain',
  templateUrl: './standalonemain.component.html',
  styleUrls: ['./standalonemain.component.css'],
  imports:[StandaloneappComponent],
  standalone:true
})
export class StandalonemainComponent {

}
