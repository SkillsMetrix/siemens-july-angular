import { Directive, ElementRef, Input, OnChanges, Renderer2, SimpleChanges } from "@angular/core";


@Directive({
    selector: '[appBold]',
    standalone:true
})
export class FontDirective implements OnChanges{

    @Input()
    weight!: string
    ngOnChanges(changes: SimpleChanges): void {
        if(changes['weight']){
            this.ren.setStyle(this.ef.nativeElement,'font-weight',this.weight) 
        }
    }
     constructor(private ef:ElementRef,private ren:Renderer2){
      
    }

}