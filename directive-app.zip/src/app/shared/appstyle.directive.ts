import { Directive, ElementRef, Renderer2 } from "@angular/core";
import { ColorDirective } from "./color.directive";
import { FontDirective } from "./FontDirective.directive";


@Directive({
    selector: '[appStyle]',
    standalone:true,
    hostDirectives:[{directive:ColorDirective, inputs:['color']},
    {directive:FontDirective, inputs:['weight']}]})
export class AppStyleDirective {
    

}