import { Directive, ElementRef, Input, OnChanges, Renderer2, SimpleChanges } from "@angular/core";


@Directive({
    selector: '[appColor]',
    standalone: true
})
export class ColorDirective implements OnChanges {

    @Input()
    color!: string

    ngOnChanges(changes: SimpleChanges): void {
        if (changes['color']) {
            this.ren.setStyle(this.ef.nativeElement, 'color', this.color)
        }
    }
    constructor(private ef: ElementRef, private ren: Renderer2) {

    }

}