import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { StandaloneappComponent } from './components/standaloneapp/standaloneapp.component';
import { StandalonemainComponent } from './components/standalonemain/standalonemain.component';

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    StandaloneappComponent,
    StandalonemainComponent,
   ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
