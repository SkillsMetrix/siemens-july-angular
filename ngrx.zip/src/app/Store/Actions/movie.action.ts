import { createAction } from "@ngrx/store";



export const getMovies=createAction('[Movie] get movie')
