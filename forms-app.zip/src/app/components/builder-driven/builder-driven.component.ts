import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-builder-driven',
  templateUrl: './builder-driven.component.html',
  styleUrls: ['./builder-driven.component.css']
})
export class BuilderDrivenComponent  implements OnInit{
   myForm:FormGroup
  addUser(){
console.log(this.myForm.value);

  }
  constructor(private fb:FormBuilder){}
  ngOnInit(): void {
    this.myForm=this.fb.group({
      uname:['',Validators.required],
      pass:['',[Validators.required,Validators.minLength(6)]],
      email:['',[Validators.required,Validators.email]],
      city:['']
    })
      
  }
      
}
