import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { FormServiceService } from 'src/app/shared/form-service.service';

@Component({
  selector: 'app-data-driven',
  templateUrl: './data-driven.component.html',
  styleUrls: ['./data-driven.component.css']
})
export class DataDrivenComponent {

  myForm: FormGroup
  uname: FormControl
  pass: FormControl
  email: FormControl
  city: FormControl

  createFormControls() {
    this.uname = new FormControl('', Validators.required)
    this.pass = new FormControl('', [Validators.required, Validators.minLength(6)])
    this.email = new FormControl('', [Validators.required, Validators.email,this.emailValidator])
    this.city = new FormControl('')
  }
  createForm() {
    this.myForm = new FormGroup({
      uname: this.uname,
      pass: this.pass,
      email: this.email,
      city: this.city
    })
  }
  constructor(private fs:FormServiceService) {
    this.createFormControls()
    this.createForm()
    this.fs.getDataFromDB()
  }

  users:any[]
getUser(){
  this.fs.getDataFromDB()
  .subscribe((res)=>{
      const myarray=[]
      for(let key in res){
        myarray.push(res[key])
      }
      this.users=myarray
  })
  
}
  addUser() {
    this.fs.addUserToDB(this.myForm.value)
    
}
emailValidator(control: FormControl) {
    let email = control.value
    if (email && email.indexOf('@') != -1) {
      let [before, domain] = email.split('@')
      if (domain !== 'siemens.com') {
        return {
          errorMessage: {
            keyname: domain
          }}}}
    return null
  }
}
