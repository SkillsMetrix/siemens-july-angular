import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormServiceService } from 'src/app/shared/form-service.service';

@Component({
  selector: 'app-template-driven',
  templateUrl: './template-driven.component.html',
  styleUrls: ['./template-driven.component.css']
})
export class TemplateDrivenComponent {

  constructor(private fs: FormServiceService) { }
  addUser(nf: NgForm) {

    this.fs.addUserToDB(nf.value)
  }


}
